<?php
return [
    'Create' => '创建',
    'Update' => '更新',
    'Create Employee' => '新建立管理员',
];